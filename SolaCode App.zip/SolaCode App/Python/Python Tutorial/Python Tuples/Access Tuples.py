# Access Tuple Items
thistuple = ("apple", "banana", "cherry")
print(thistuple[1]) # Output: banana


# Negative Indexing
thistuple = ("apple", "banana", "cherry")
print(thistuple[-1]) # Output: cherry


# Range of Indexes
thistuple = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
print(thistuple[2:5]) # Output: ('cherry', 'orange', 'kiwi')


# Range of Negative Indexes
thistuple = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
print(thistuple[-4:-1]) # Output: ('orange', 'kiwi', 'melon')


# Check if Item Exists
thistuple = ("apple", "banana", "cherry")
if "apple" in thistuple:
  print("Yes, 'apple' is in the fruits tuple")