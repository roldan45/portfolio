# Access Dictionary Items
# Accessing Items
thisdict = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
x = thisdict["model"]
print(x)  # Output: Mustang


# get() method
x = thisdict.get("model")
print(x)  # Output: Mustang


# Get Keys
x = thisdict.keys()
print(x)  # Output: dict_keys(['brand', 'model', 'year'])


# Example
car = {
"brand": "Ford",
"model": "Mustang",
"year": 1964
}
x = car.keys()
print(x) # Output: dict_keys(['brand', 'model', 'year'])
car["color"] = "white"
print(x) # Output: dict_keys(['brand', 'model', 'year', 'color'])


# Get Values
car = {
"brand": "Ford",
"model": "Mustang",
"year": 1964
}
x = car.values()
print(x) # Output: dict_values(['Ford', 'Mustang', 1964])
car["year"] = 2020
print(x) # Output: dict_values(['Ford', 'Mustang', 2020])


# Example Add a new item
car = {
"brand": "Ford",
"model": "Mustang",
"year": 1964
}
x = car.values()
print(x) # Output: dict_values(['Ford', 'Mustang', 1964])
car["color"] = "red"
print(x) # Output: dict_values(['Ford', 'Mustang', 1964, 'red'])


# Get Items
car = {
"brand": "Ford",
"model": "Mustang",
"year": 1964
}
x = car.items()
print(x) # Output: dict_items([('brand', 'Ford'), ('model', 'Mustang'), ('year', 1964)])
car["year"] = 2020
print(x) # Output: dict_items([('brand', 'Ford'), ('model', 'Mustang'), ('year', 2020)])


# Check if Key Exists
thisdict = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
if "model" in thisdict:
  print("Yes, 'model' is one of the keys in the thisdict dictionary")