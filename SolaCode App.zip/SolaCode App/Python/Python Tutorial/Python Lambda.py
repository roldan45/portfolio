# Python Lambda
# Syntax
# lambda arguments : expression


# Add 10 to argument a
x = lambda a : a + 10
print(x(5)) # Output: 15


# Multiply argument a with argument b
x = lambda a, b : a * b
print(x(5, 6)) # Output: 30


# Summarize argument a, b, and c
x = lambda a, b, c : a + b + c
print(x(5, 6, 2)) # Output: 13


# Use a lambda function within a function
def myfunc(n):
  return lambda a : a * n
mydoubler = myfunc(2)
print(mydoubler(11)) # Output: 22


# Use a lambda function within a function with multiple instances
def myfunc(n):
  return lambda a : a * n
mydoubler = myfunc(2)
mytripler = myfunc(3)
print(mydoubler(11))
print(mytripler(11))