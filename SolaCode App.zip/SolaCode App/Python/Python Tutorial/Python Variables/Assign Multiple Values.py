# Many Values to Multiple Variables
x, y, z = "Orange", "Banana", "Cherry"
print(x)
print(y)
print(z)


# One Value to Multiple Variables
a = b = c = "Orange"
print(a)
print(b)
print(c)


# Unpack a Collection
fruits = ["Apple", "Banana", "Cherry"]
d, e, f = fruits
print(d)
print(e)
print(f)