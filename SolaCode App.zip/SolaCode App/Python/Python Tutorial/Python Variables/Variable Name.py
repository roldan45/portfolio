# Multi Words Variable Names
# Camel Case
myVariableName = "Harold"


# Pascal Case
MyVariableName = "Harold"


# Snake Case
my_variable_name = "Harold"
