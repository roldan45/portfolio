# Global Variables
x = "awesome"
def myfunc():
  x = "fantastic"
  print("Python is " + x) # Output: Python is fantastic
myfunc() # Output: 
print("Python is " + x) # Output: Python is awesome  


# The global Keyword
x = "awesome"
def myfunc():
  global x
  x = "fantastic"
myfunc()
print("Python is " + x) # Output: Python is fantastic