# Remove Set Items
# Remove Item
thisset = {"apple", "banana", "cherry"}
thisset.remove("banana")
print(thisset) # Output: {'cherry', 'apple'}


# Using dscard
thisset = {"apple", "banana", "cherry"}
thisset.discard("banana")
print(thisset) # Output: {'cherry', 'apple'}


# Using pop
thisset = {"apple", "banana", "cherry"}
x = thisset.pop()
print(x)
print(thisset)# Output: {'cherry', 'banana'} (or {'banana', 'cherry'}, order may vary)


# Using del
thisset = {"apple", "banana", "cherry"}
del thisset
print(thisset) # Raises NameError: name 'thisset' is not defined
