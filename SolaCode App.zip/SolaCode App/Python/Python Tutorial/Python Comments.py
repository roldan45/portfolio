#This is a comment
print("Hello, World!") # This line prints a message to the console
"""
This is a comment
written in
more than just one line
"""
print("Hello, World!")