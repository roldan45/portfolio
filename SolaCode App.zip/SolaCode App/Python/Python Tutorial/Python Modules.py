# Python Modules
# A file containing a set of functions you want to include in your application.

# Create a Module
# Save this code in a file named mymodule.py
def greeting(name):
    print("Hello, " + name)


# Use a Module
import mymodule

mymodule.greeting("Jonathan") # Output: Hello, Jonathan


# Variables in Module
# Save this code in a file named mymodule.py
person1 = {
  "name": "John",
  "age": 36,
  "country": "Norway"
}


# Use a Module
import mymodule

a = mymodule.person1["age"]
print(a) # Output: 36


# Re-naming a Module (Alias)
import mymodule as mx

a = mx.person1["age"]
print(a)


# Built-in Modules
import platform

x = platform.system()
print(x) # Output: Windows (or Linux, Darwin, etc. depending on your OS)


# Using the dir() Function
import platform

x = dir(platform)
print(x) # Output: ['BINDING_VERSION', 'C_API_VERSION', 'Compiler', 'PythonBuild', 'PythonCompiler', 'PythonVersion', ...]


# Import From Module
# Save this code in a file named mymodule.py
def greeting(name):
  print("Hello, " + name)
person1 = {
  "name": "John",
  "age": 36,
  "country": "Norway"
}


# Use the from keyword to import specific parts of a module
from mymodule import person1

print (person1["age"]) # Output: 36

