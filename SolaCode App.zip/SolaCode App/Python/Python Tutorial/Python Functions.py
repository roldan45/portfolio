# Python Functions
# Creating a Function
def my_function():
  print("Hello from a function")


# Calling a Function
my_function()  # Output: Hello from a function


# Arguments
def my_function(fname):
  print(fname + " Refsnes")
my_function("Emil") # Output: Emil Refsnes
my_function("Tobias") # Output: Tobias Refsnes
my_function("Linus") # Output: Linus Refsnes


# Number of Arguments
def my_function(fname, lname):
  print(fname + " " + lname)
my_function("Emil", "Refsnes") # Output: Emil Refsnes
my_function("Emil") # This will raise an error because it requires two arguments


# Arbitrary Arguments, *args
def my_function(*kids):
  print("The youngest child is " + kids[2])
my_function("Emil", "Tobias", "Linus") # Output: The youngest child is Linus


# Keyword Arguments
def my_function(child3, child2, child1):
  print("The youngest child is " + child3)
my_function(child1 = "Emil", child2 = "Tobias", child3 = "Linus") # Output: The youngest child is Linus


# Arbitrary Keyword Arguments, **kwargs
def my_function(**kid):
  print("His last name is " + kid["lname"])
my_function(fname = "Tobias", lname = "Refsnes") # Output: His last name is Refsnes


# Default Parameter Value
def my_function(country = "Norway"):
  print("I am from " + country)
my_function("Sweden")  # Output: I am from Sweden
my_function("India") # Output: I am from India
my_function() # Output: I am from Norway
my_function("Brazil") # Output: I am from Brazil


# Passing a List as an Argument
def my_function(food):
  for x in food:
    print(x)
fruits = ["apple", "banana", "cherry"]
my_function(fruits) # Output:
# apple
# banana
# cherry


# Return Values
def my_function(x):
  return 5 * x
print(my_function(3)) # Output: 15
print(my_function(5)) # Output: 25
print(my_function(9)) # Output: 45


# The pass Statement
def my_function():
  pass  # This function does nothing   


# Positional-Only Arguments
def my_function(x, /): # ONLY positional arguments or ONLY keyword arguments.
  print(x)
my_function(3) # Output: 3
# my_function(x = 3) # This will raise an error because x is a positional-only argument


# Keyword-Only Arguments
def my_function(*, x):
  print(x)
my_function(x = 3) # Output: 3
# my_function(3) # This will raise an error because x is a keyword-only argument


# Combine Positional-Only and Keyword-Only
def my_function(a, b, /, *, c, d):
  print(a + b + c + d)
my_function(5, 6, c = 7, d = 8) # Output: 26
# my_function(5, 6, 7, 8) # This will raise an error because c and d must be keyword arguments


# Recursion means a function calls itself.
def tri_recursion(k):
  if(k > 0):
    result = k + tri_recursion(k - 1)
    print(result)
  else:
    result = 0
  return result
print("Recursion Example Results:")
tri_recursion(6) # Output:
# 1
# 3
# 6
# 10
# etc.