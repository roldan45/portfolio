# String Methods
# Method	      Description
# capitalize()    Converts the first character to upper case
# casefold()      Converts string into lower case
# center()        Returns a centered string
# count()         Returns the number of times a specified value occurs in a string
# encode()        Returns an encoded version of the string
# endswith()      Returns true if the string ends with the specified value
# expandtabs()    Sets the tab size of the string
# find()          Searches the string for a specified value and returns the position of where it was found
# format()        Formats specified values in a string
# format_map()    Formats specified values in a string
# index()         Searches the string for a specified value and returns the position of where it was found
# isalnum()       Returns True if all characters in the string are alphanumeric
# isalpha()       Returns True if all characters in the string are in the alphabet
# isascii()       Returns True if all characters in the string are ascii characters
# isdecimal()     Returns True if all characters in the string are decimals
# isdigit()       Returns True if all characters in the string are digits
# isidentifier()  Returns True if the string is an identifier
# islower()       Returns True if all characters in the string are lower case
# isnumeric()     Returns True if all characters in the string are numeric
# isprintable()   Returns True if all characters in the string are printable
# isspace()       Returns True if all characters in the string are whitespaces
# istitle()       Returns True if the string follows the rules of a title
# isupper()       Returns True if all characters in the string are upper case
# join()          Joins the elements of an iterable to the end of the string
# ljust()         Returns a left justified version of the string
# lower()         Converts a string into lower case
# lstrip()        Returns a left trim version of the string
# maketrans()     Returns a translation table to be used in translations
# partition()     Returns a tuple where the string is parted into three parts
# replace()       Returns a string where a specified value is replaced with a specified value
# rfind()         Searches the string for a specified value and returns the last position of where it was found
# rindex()        Searches the string for a specified value and returns the last position of where it was found
# rjust()         Returns a right justified version of the string
# rpartition()    Returns a tuple where the string is parted into three parts
# rsplit()        Splits the string at the specified separator, and returns a list
# rstrip()        Returns a right trim version of the string
# split()         Splits the string at the specified separator, and returns a list
# splitlines()    Splits the string at line breaks and returns a list
# startswith()    Returns true if the string starts with the specified value
# strip()         Returns a trimmed version of the string
# swapcase()      Swaps cases, lower case becomes upper case and vice versa
# title()         Converts the first character of each word to upper case
# translate()     Returns a translated string
# upper()         Converts a string into upper case
# zfill()         Fills the string with a specified number of 0 values at the beginning

# _____________________________________________________


# capitalize()
s = "hello world"
print(s.capitalize())  # Output: 'Hello world'

# casefold()
s = "HELLO"
print(s.casefold())  # Output: 'hello'

# center()
s = "hi"
print(s.center(10, '-'))  # Output: '----hi----'

# count()
s = "banana"
print(s.count('a'))  # Output: 3

# encode()
s = "hello"
print(s.encode())  # Output: b'hello'

# endswith()
s = "hello.txt"
print(s.endswith('.txt'))  # Output: True

# expandtabs()
s = "a\tb"
print(s.expandtabs(4))  # Output: 'a   b'

# find()
s = "hello"
print(s.find('e'))  # Output: 1

# format()
print("Hello, {}!".format("Alice"))  # Output: 'Hello, Alice!'

# format_map()
print("{name} is {age}".format_map({'name': 'Bob', 'age': 25}))  # Output: 'Bob is 25'

# index()
s = "hello"
print(s.index('e'))  # Output: 1

# isalnum()
s = "abc123"
print(s.isalnum())  # Output: True

# isalpha()
s = "abc"
print(s.isalpha())  # Output: True

# isascii()
s = "abc"
print(s.isascii())  # Output: True

# isdecimal()
s = "123"
print(s.isdecimal())  # Output: True

# isdigit()
s = "123"
print(s.isdigit())  # Output: True

# isidentifier()
s = "var_1"
print(s.isidentifier())  # Output: True

# islower()
s = "hello"
print(s.islower())  # Output: True

# isnumeric()
s = "123"
print(s.isnumeric())  # Output: True

# isprintable()
s = "abc"
print(s.isprintable())  # Output: True

# isspace()
s = "   "
print(s.isspace())  # Output: True

# istitle()
s = "Hello World"
print(s.istitle())  # Output: True

# isupper()
s = "HELLO"
print(s.isupper())  # Output: True

# join()
s = ","
print(s.join(["a", "b", "c"]))  # Output: 'a,b,c'

# ljust()
s = "hi"
print(s.ljust(5, '-'))  # Output: 'hi---'

# lower()
s = "HELLO"
print(s.lower())  # Output: 'hello'

# lstrip()
s = "   hello"
print(s.lstrip())  # Output: 'hello'

# maketrans()
trans = str.maketrans('abc', '123')
print("abc".translate(trans))  # Output: '123'

# partition()
s = "hello world"
print(s.partition(" "))  # Output: ('hello', ' ', 'world')

# replace()
s = "banana"
print(s.replace('a', 'o'))  # Output: 'bonono'

# rfind()
s = "banana"
print(s.rfind('a'))  # Output: 5

# rindex()
s = "banana"
print(s.rindex('a'))  # Output: 5

# rjust()
s = "hi"
print(s.rjust(5, '-'))  # Output: '---hi'

# rpartition()
s = "hello world"
print(s.rpartition(" "))  # Output: ('hello', ' ', 'world')

# rsplit()
s = "a,b,c"
print(s.rsplit(","))  # Output: ['a', 'b', 'c']

# rstrip()
s = "hello   "
print(s.rstrip())  # Output: 'hello'

# split()
s = "a b c"
print(s.split())  # Output: ['a', 'b', 'c']

# splitlines()
s = "a\nb\nc"
print(s.splitlines())  # Output: ['a', 'b', 'c']

# startswith()
s = "hello world"
print(s.startswith("hello"))  # Output: True

# strip()
s = "   hello   "
print(s.strip())  # Output: 'hello'

# swapcase()
s = "Hello"
print(s.swapcase())  # Output: 'hELLO'

# title()
s = "hello world"
print(s.title())  # Output: 'Hello World'

# translate()
trans = str.maketrans('ae', '12')
print("apple".translate(trans))  # Output: '1ppl2'

# upper()
s = "hello"
print(s.upper())  # Output: 'HELLO'

# zfill()
s = "42"
print(s.zfill(5))  # Output: '00042'