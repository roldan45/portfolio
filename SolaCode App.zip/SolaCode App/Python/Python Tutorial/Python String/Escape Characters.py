# Escape Character
txt = "We are the so-called \"Vikings\" from the north."
print(txt)  # Output: We are the so-called "Vikings" from the north.


# Escape Characters in Python
# \'  Single Quote
single_quote_example = 'It\'s a beautiful day.'
print(single_quote_example)  # Output: It's a beautiful day.

# \\  Backslash
backslash_example = "This is a backslash: \\"
print(backslash_example)  # Output: This is a backslash: \

# \n  New Line
newline_example = "Hello\nWorld"
print(newline_example)  # Output: Hello
                        #         World

# \r  Carriage Return
carriage_return_example = "Hello\rWorld"
print(carriage_return_example)  # Output may vary: World

# \t  Tab
tab_example = "Hello\tWorld"
print(tab_example)  # Output: Hello   World

# \b  Backspace
backspace_example = "Hello\bWorld"
print(backspace_example)  # Output: HellWorld

# \f  Form Feed
formfeed_example = "Hello\fWorld"
print(formfeed_example)  # Output: HelloWorld

# \ooo  Octal value
octal_example = "\110\145\154\154\157"
print(octal_example)  # Output: Hello

# \xhh  Hex value
hex_example = "\x48\x65\x6c\x6c\x6f"
print(hex_example)  # Output: Hello