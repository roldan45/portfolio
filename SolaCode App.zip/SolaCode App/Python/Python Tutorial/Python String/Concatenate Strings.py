# String Concatenation
# Example
a = "Hello"
b = "World"
c = a + b
print(c)  # Output: HelloWorld


# Example
a = "Hello"
b = "World"
c = a + " " + b
print(c)  # Output: Hello World
