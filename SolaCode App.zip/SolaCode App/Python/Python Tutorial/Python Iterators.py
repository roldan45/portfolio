# Python Iterators
# An iterator is an object that contains a countable number of values.

# Iterator vs Iterable
# An iterable is an object that can return an iterator.
# Examples of iterables include lists, tuples, and strings.
# An iterator is an object that implements the iterator protocol, which consists of the methods __iter__() and __next__().


# Example
mytuple = ("apple", "banana", "cherry")
myit = iter(mytuple)
print(next(myit)) # Output: apple
print(next(myit)) # Output: banana
print(next(myit)) # Output: cherry


# Example
mystr = "banana"
myit = iter(mystr)
print(next(myit)) # Output: b
print(next(myit)) # Output: a
print(next(myit)) # Output: n
print(next(myit)) # Output: a
print(next(myit)) # Output: n
print(next(myit)) # Output: a


# Looping Through an Iterator
mytuple = ("apple", "banana", "cherry")
for x in mytuple:
  print(x)


# Create an Iterator
class MyNumbers:
  def __iter__(self):
    self.a = 1
    return self

  def __next__(self):
    x = self.a
    self.a += 1
    return x

myclass = MyNumbers()
myiter = iter(myclass)
print(next(myiter)) # Output: 1
print(next(myiter)) # Output: 2
print(next(myiter)) # Output: 3
print(next(myiter)) # Output: 4
print(next(myiter)) # Output: 5


# StopIteration
# To prevent the iteration from going on forever, we can use the StopIteration statement.
class MyNumbers:
  def __iter__(self):
    self.a = 1
    return self

  def __next__(self):
    if self.a <= 20:
      x = self.a
      self.a += 1
      return x
    else:
      raise StopIteration

myclass = MyNumbers()
myiter = iter(myclass)
for x in myiter:
  print(x)