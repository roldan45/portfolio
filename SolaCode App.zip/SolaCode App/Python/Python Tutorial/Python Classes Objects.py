# Python Classes/Objects
# Create a Class
class MyClass:
    x = 5


# Create an object of MyClass
p1 = MyClass()
print(p1.x)  # Outputs: 5


# The __init__() Function
# The __init__() function is a special method that is called when an object is created.
# It is used to initialize the object's attributes.
class Person:
  def __init__(self, name, age):
    self.name = name
    self.age = age

p1 = Person("John", 36)
print(p1.name) # Outputs: John
print(p1.age) # Outputs: 36


# The __str__() Function
# The __str__() function is a special method that is called when the str() function is called on an object.
# It is used to return a string representation of the object.
class Person:
  def __init__(self, name, age):
    self.name = name
    self.age = age

  def __str__(self):
    return f"{self.name}({self.age})"

p1 = Person("John", 36)
print(p1) # Outputs: John(36)


# Object Methods
class Person:
  def __init__(self, name, age):
    self.name = name
    self.age = age

  def myfunc(self):
    print("Hello my name is " + self.name)

p1 = Person("John", 36)
p1.myfunc() # Outputs: Hello my name is John


# The self Parameter
# The self parameter is a reference to the current instance of the class.
class Person:
  def __init__(mysillyobject, name, age):
    mysillyobject.name = name
    mysillyobject.age = age

  def myfunc(abc):
    print("Hello my name is " + abc.name)

p1 = Person("John", 36)
p1.myfunc() # Outputs: Hello my name is John


# Modify Object Properties
p1.age = 40


# Delete Object Properties
del p1.age


# The pass Statement
class Person:
  pass