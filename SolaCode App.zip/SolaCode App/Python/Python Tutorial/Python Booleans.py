# Python Booleans
# Boolean Values
a = True
b = False


# Type
print(type(a))  # <class 'bool'>


# isinstance -- used to determine if an object is a certain data type
print(isinstance(a, bool))  # True
print(isinstance(5, int))   # True
print(isinstance("hello", str))  # True


# Comparison Operators
print(5 == 5)    # True
print(5 != 3)    # True
print(5 > 3)     # True
print(5 < 3)     # False
print(5 >= 5)    # True
print(5 <= 4)    # False


# Logical Operators
x = True
y = False
print(x and y)   # False
print(x or y)    # True
print(not x)     # False


# Boolean Conversion
print(bool(0))        # False
print(bool(1))        # True
print(bool(""))       # False
print(bool("Hello"))  # True
print(bool([]))       # False
print(bool([1,2,3]))  # True


# Conditional Statements
if a:
    print("a is True")
else:
    print("a is False")


# None is not True
print(bool(None))     # False


# Custom Objects
class MyClass:
    def __bool__(self):
        return False
obj = MyClass()
print(bool(obj))      # False