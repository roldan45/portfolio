# Python PIP
# PIP is a package manager for Python packages, or modules if you like.


# Check if PIP is Installed
# Go to your command line (cmd) and type:
# pip --version


# Install PIP
# https://pypi.org/project/pip/


# Download a Package
# pip install camelcase


# Using a Package
import camelcase

c = camelcase.CamelCase()
txt = "hello world"
print(c.hump(txt)) # Output: Hello World


# Find Packages
# https://pypi.org/.


# Remove a Package
# pip uninstall camelcase


# List Packages
# pip list


