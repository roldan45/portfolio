# Python Syntax
print('hello world')