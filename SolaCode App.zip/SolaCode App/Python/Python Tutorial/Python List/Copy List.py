# Copy Lists
# Use the copy() method
thislist = ["apple", "banana", "cherry"]
mylist = thislist.copy()
print(mylist) # Output: ['apple', 'banana', 'cherry']


# Use the list() method
thislist = ["apple", "banana", "cherry"]
mylist = list(thislist)
print(mylist) # Output: ['apple', 'banana', 'cherry']


# Use the slice Operator
thislist = ["apple", "banana", "cherry"]
mylist = thislist[:]
print(mylist) # Output: ['apple', 'banana', 'cherry']

