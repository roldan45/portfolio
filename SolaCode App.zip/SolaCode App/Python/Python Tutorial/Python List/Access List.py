# Access List Items
# Access Items
thislist = ["apple", "banana", "cherry"]
print(thislist[1])  # Output: banana


# Negative Indexing
thislist = ["apple", "banana", "cherry"]
print(thislist[-1]) # Output: cherry


# Range of Indexes
thislist = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(thislist[2:5])  # Output: ['cherry', 'orange', 'kiwi']


# Range of Negative Indexes
thislist = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(thislist[-4:-1]) # Output: ['orange', 'kiwi', 'melon']


# Check if Item Exists
thislist = ["apple", "banana", "cherry"]
if "apple" in thislist:
    print("Yes, 'apple' is in the fruits list") # Output: Yes, 'apple' is in the fruits list