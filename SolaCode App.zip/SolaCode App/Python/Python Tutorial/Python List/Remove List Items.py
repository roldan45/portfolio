# Remove List Items
# Remove Specified Item
thislist = ["apple", "banana", "cherry", "banana", "kiwi"]
thislist.remove("banana")
print(thislist)  # Output: ['apple', 'cherry', 'banana', 'kiwi']


# Remove Specified Index
thislist = ["apple", "banana", "cherry"]
thislist.pop(1)
print(thislist)  # Output: ['apple', 'cherry']


# Remove Last Item
thislist = ["apple", "banana", "cherry"]
thislist.pop()
print(thislist) # Output: ['apple', 'banana']


# Delete List Items
thislist = ["apple", "banana", "cherry"]
del thislist[0]
print(thislist) # Output: ['banana', 'cherry']


# Delete the List
thislist = ["apple", "banana", "cherry"]
del thislist
print(thislist)  # Output: []


# Clear the List
thislist = ["apple", "banana", "cherry"]
thislist.clear()
print(thislist) # Output: []