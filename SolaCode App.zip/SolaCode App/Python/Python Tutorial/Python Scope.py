# Python Scope

# Local Scope
# Can only be used inside that function.
def myfunc():
  x = 300
  print(x)
myfunc() # Output: 300


# Function Inside Function
def myfunc():
  x = 300
  def myinnerfunc():
    print(x)
  myinnerfunc()
myfunc() # Output: 300


# Global Scope
# Variable can be used by anyone.
x = 300
def myfunc():
  print(x)
myfunc()
print(x) # Output: 300


# Naming Variables
x = 300
def myfunc():
  x = 200
  print(x)
myfunc() # Output: 200
print(x)# Output: 300
# The function uses the local variable x, which is 200, while the global variable x remains unchanged at 300.


# Global Keyword
def myfunc():
  global x
  x = 300
myfunc() # Now x is a global variable 
print(x) # Output: 300


# Nonlocal Keyword
# Variable will belong to the outer function
def myfunc1():
  x = "Jane"
  def myfunc2():
    nonlocal x
    x = "hello"
  myfunc2()
  return x
print(myfunc1()) # Output: hello