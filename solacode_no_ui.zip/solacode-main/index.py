import sys
import os
from pygments import highlight
from pygments.lexers import get_lexer_for_filename, get_lexer_by_name
from pygments.formatters import TerminalFormatter
from pygments.util import ClassNotFound


def starting_page():
    print("________________________________________________________________________")
    print("SolaCode")
    print("The Sola Code is a Cheat Sheet for people who are lazy to read.")
    button = input("Start? (1 to start): ")
    if button == "1":
        dashboard()
    else:
        print("K Byeeee!")
        sys.exit()

def dashboard():
    print("________________________________________________________________________")
    print("\nDashboard")
    print("Pick Language:\n")

    folder_path = "."
    folders = []
    for f in os.listdir(folder_path):
        full_path = os.path.join(folder_path, f)
        if os.path.isdir(full_path) and not f.startswith('.'):  # Skip hidden folders
            folders.append(f)

    if not folders:
        print("No languages (folders) found.")
        sys.exit()

    for idx, folder in enumerate(folders, 1):
        print(f"{idx}. {folder}")
    
    choose_language(folders)

def choose_language(folders):
    while True:
        choice = input("\nPick Language (number) or 0 to go back: ")
        if choice.isdigit():
            index = int(choice) - 1
            if int(choice) == 0:
                starting_page()
                return
            elif 0 <= index < len(folders):
                selected_language = folders[index]
                print(f"\nYou selected: {selected_language}")
                print("________________________________________________________________________")
                pick = input("\nPick:\n1 Learn\n2 Exam\n0 back\n")
                if pick == "1":
                    learn(selected_language)
                    return
                elif pick == "2":
                    exam()
                    return
                elif pick == "0":
                    dashboard()
                    return
                else:
                    print("Invalid option.")
            else:
                print("Invalid choice.")
        else:
            print("Please enter a valid number.")

def learn(language_name):
    language_path = os.path.join(".", language_name)
    modules = []

    for f in os.listdir(language_path):
        full_path = os.path.join(language_path, f)
        if os.path.isdir(full_path):
            modules.append(f)

    if not modules:
        print("No modules (folders) found.")
        input("Press Enter to go back...")
        dashboard()
        return
    
    print("________________________________________________________________________")
    print("\nAvailable Modules:")
    
    while True:
        for idx, module in enumerate(modules, 1):
            print(f"{idx}. {module}")

        choice = input("\nPick Module (number) or 0 to go back: ")
        if choice == "0":
            dashboard()
            return
        elif choice.isdigit():
            index = int(choice) - 1
            if 0 <= index < len(modules):
                selected_module = modules[index]
                print("________________________________________________________________________")
                print(f"\nYou selected module: {modules[index]}")
                read(language_name, selected_module)
                return
            else:
                print("Invalid module choice.")
        else:
            print("Invalid input.")

def read(language_folder, selected_module):
    module_directory = os.path.join(".", language_folder, selected_module)
    file_list = []

    for filename in os.listdir(module_directory):
        file_list.append(filename)
    
    if not file_list:
        print("No files found in this module.")
        input("Press Enter to go back...")
        learn(language_folder)
        return
    
    print("\nFiles in this module:")
    for index, filename in enumerate(file_list, 1):
        print(f"{index}. {filename}")

    while True:
        user_choice = input("\nPick file to read (number) or 0 to go back: ")
        
        if user_choice == "0":
            learn(language_folder)
            return
        elif user_choice.isdigit():
            selected_index = int(user_choice) - 1
            if 0 <= selected_index < len(file_list):
                selected_fp = os.path.join(module_directory, file_list[selected_index])
                
                if os.path.isdir(selected_fp):
                    handle_subdirectory(selected_fp, language_folder, selected_module)
                    return
                else:
                    open_read(selected_fp, file_list[selected_index], language_folder, selected_module)
                    return
            else:
                print("Invalid file choice.")
        else:
            print("Invalid input.")

def handle_subdirectory(subdirectory_path, language_folder, selected_module):
    sub_file_list = []
    for sub_fn in os.listdir(subdirectory_path):
        sub_file_list.append(sub_fn)
    
    if not sub_file_list:
        print("No files found in this subdirectory.")
        input("Press Enter to go back...")
        read(language_folder, selected_module)
        return
    
    print("________________________________________________________________________")
    print("\nFiles in subdirectory:")
    for sub_index, sub_fn in enumerate(sub_file_list, 1):
        print(f"{sub_index}. {sub_fn}")
    
    while True:
        sub_file_choice = input("\nPick file to read (number) or 0 to go back: ")
        if sub_file_choice == "0":
            read(language_folder, selected_module)
            return
        elif sub_file_choice.isdigit():
            selected_index_2 = int(sub_file_choice) - 1
            if 0 <= selected_index_2 < len(sub_file_list):
                selected_fp_2 = os.path.join(subdirectory_path, sub_file_list[selected_index_2])
                
                if os.path.isdir(selected_fp_2):
                    # Handle deeper subdirectory
                    handle_deeper_subdirectory(selected_fp_2, language_folder, selected_module)
                    return
                else:
                    open_read(selected_fp_2, sub_file_list[selected_index_2], language_folder, selected_module)
                    return
            else:
                print("Invalid file choice.")
        else:
            print("Invalid input.")

def handle_deeper_subdirectory(deeper_subdirectory_path, language_folder, selected_module):
    sub_file_list_2 = []
    for sub_fn_2 in os.listdir(deeper_subdirectory_path):
        sub_file_list_2.append(sub_fn_2)
    
    if not sub_file_list_2:
        print("No files found in this subdirectory.")
        input("Press Enter to go back...")
        read(language_folder, selected_module)
        return
    
    print("\nFiles in deeper subdirectory:")
    for sub_index_2, sub_fn_2 in enumerate(sub_file_list_2, 1):
        print(f"{sub_index_2}. {sub_fn_2}")
    
    while True:
        deeper_choice = input("\nPick file to read (number) or 0 to go back: ")
        if deeper_choice == "0":
            read(language_folder, selected_module)
            return
        elif deeper_choice.isdigit():
            deeper_index = int(deeper_choice) - 1
            if 0 <= deeper_index < len(sub_file_list_2):
                deeper_fp = os.path.join(deeper_subdirectory_path, sub_file_list_2[deeper_index])
                open_read(deeper_fp, sub_file_list_2[deeper_index], language_folder, selected_module)
                return
            else:
                print("Invalid choice.")
        else:
            print("Invalid input.")

def open_read(fp, flindex, lang_folder, sel_module):
    try:
        with open(fp, 'r', encoding='utf-8') as file:
            fc = file.read()
            print("________________________________________________________________________")
            display_file_with_syntax_highlighting(fp, fc, flindex)
            input("\nPress Enter to continue...")
            read(lang_folder, sel_module)
    except FileNotFoundError:
        print(f"Error: File '{fp}' not found.")
        input("Press Enter to continue...")
        read(lang_folder, sel_module)
    except Exception as e:
        print(f"Error reading file: {e}")
        input("Press Enter to continue...")
        read(lang_folder, sel_module)

def display_file_with_syntax_highlighting(file_path, file_content, filename):
    try:
        lexer = get_lexer_for_filename(file_path)
    except ClassNotFound:
        try:
            lexer = get_lexer_by_name('text')
        except ClassNotFound:
            # Fallback to plain text
            lexer = get_lexer_by_name('text')
    
    try:
        formatter = TerminalFormatter(bg='dark')
        highlighted_code = highlight(file_content, lexer, formatter)
        print(f"\n--- {filename} ---\n")
        print(highlighted_code)
    except Exception as e:
        # If highlighting fails, display plain text
        print(f"\n--- {filename} ---\n")
        print(file_content)
        print(f"\n[Note: Syntax highlighting failed: {e}]")

def exam():
    print("Exam function - Under development")
    input("Press Enter to go back...")
    dashboard()

if __name__ == "__main__":
    starting_page()