# Python File Open

# Open a File on the Server
f = open("demofile.txt")
print(f.read())


# Different location
f = open("D:\\myfiles\welcome.txt")
print(f.read())


# With statement
with open("demofile.txt") as f:
  print(f.read())


# Close Files
f = open("demofile.txt")
print(f.readline())
f.close()


# Read Only Parts of the File
with open("demofile.txt") as f:
  print(f.read(5)) # Return the 5 first characters of the file


# Read Lines
with open("demofile.txt") as f:
  print(f.readline()) # Read one line of the file


# Loop through the file line by line
with open("demofile.txt") as f:
  for x in f:
    print(x)