# Python Numbers
x = 1    # int
y = 2.8  # float
z = 1j   # complex


# type() function
print(type(x)) # Output: <class 'int'>
print(type(y)) # Output: <class 'float'>
print(type(z)) # Output: <class 'complex'>


# Int
x = 1
y = 35656222554887711
z = -3255522
print(type(x)) # Output: <class 'int'>
print(type(y)) # Output: <class 'int'>
print(type(z)) # Output: <class 'int'>


# Float
x = 1.10
y = 1.0
z = -35.59
print(type(x)) # Output: <class 'float'>
print(type(y)) # Output: <class 'float'>
print(type(z)) # Output: <class 'float'>


# Float can also be scientific numbers with an "e" to indicate the power of 10.
x = 35e3
y = 12E4
z = -87.7e100
print(type(x)) # Output: <class 'float'>
print(type(y)) # Output: <class 'float'>
print(type(z)) # Output: <class 'float'>


# Complex
# Complex numbers are written with a "j" as the imaginary part
x = 3+5j
y = 5j
z = -5j
print(type(x)) # Output: <class 'complex'>
print(type(y)) # Output: <class 'complex'>
print(type(z)) # Output: <class 'complex'>


# Type Conversion
x = 1    # int
y = 2.8  # float
z = 1j   # complex
a = float(x) #convert from int to float
b = int(y) #convert from float to int
c = complex(x) #convert from int to complex
print(a) # Output: 1.0
print(b) # Output: 2
print(c) # Output: <class 'complex'>
print(type(a)) # Output: <class 'complex'>
print(type(b)) # Output: <class 'complex'>
print(type(c)) # Output: <class 'complex'>


# Random Number Generation
import random

print(random.randrange(1, 10)) # Output: 3