# Python OOP
# OOP stands for Object-Oriented Programming.
# Provides a clear structure to programs
# Makes code easier to maintain, reuse, and debug
# Helps keep your code DRY (Don't Repeat Yourself)
# Allows you to build reusable applications with less code


# Classes and Objects
# A class is like a blueprint for creating objects.
# An object is an instance of a class.


# Example of OOP in Python
class Car:
    # A class variable
    wheels = 4

    # The init method is a constructor that initializes the object
    def __init__(self, make, model):
        self.make = make  # Instance variable
        self.model = model  # Instance variable

    # A method to display car details
    def display_info(self):
        print(f"Car Make: {self.make}, Model: {self.model}, Wheels: {self.wheels}")

# Creating an object of the Car class
my_car = Car("Toyota", "Corolla")

# Accessing object properties
print(my_car.make)  # Output: Toyota
print(my_car.model)  # Output: Corolla

# Calling a method of the object
my_car.display_info()  # Output: Car Make: Toyota, Model: Corolla, Wheels: 4

# Creating another object of the Car class
my_second_car = Car("Honda", "Civic")

# Accessing properties of the second object
print(my_second_car.make)  # Output: Honda
print(my_second_car.model)  # Output: Civic

# Calling the method of the second object
my_second_car.display_info()  # Output: Car Make: Honda, Model: Civic, Wheels: 4

# Accessing class variable
print(Car.wheels)  # Output: 4

# Modifying class variable
Car.wheels = 5
