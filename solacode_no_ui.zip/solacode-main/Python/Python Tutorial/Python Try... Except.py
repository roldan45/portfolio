# Python Try Except

# Try block
# The try block lets you test a block of code for errors.
try:
  print(x)
except:
  print("An exception occurred")


# Else
# The else block will execute if the try block does not raise an exception.
try:
  print("Hello")
except:
  print("Something went wrong")
else:
  print("Nothing went wrong")


# Finally block
# The finally block will always execute, regardless of whether an exception occurred or not.
try:
  print(x)
except:
  print("Something went wrong")
finally:
  print("The 'try except' is finished")


# Raise an exception
# Raise an error and stop the program execution.
x = -1
if x < 0:
  raise Exception("Sorry, no numbers below zero")


# You can define what kind of error to raise, and the text to print to the user.
x = "hello"
if not type(x) is int:
  raise TypeError("Only integers are allowed")
