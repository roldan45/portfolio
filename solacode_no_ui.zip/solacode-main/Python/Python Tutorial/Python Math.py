# Python Math
# Built-in Math Functions

# min() and max() functions
x = min(5, 10, 25)
y = max(5, 10, 25)
print(x) # Output: 5
print(y) # Output: 25


# abs() function
x = abs(-7.25)
print(x) # Output: 7.25


# pow(x, y)
x = pow(4, 3)
print(x) # Output: 64


# The Math Module
import math

x = math.sqrt(64)
print(x) # Output: 8.0


# Example
import math

x = math.ceil(1.4)
y = math.floor(1.4)
print(x) # returns 2
print(y) # returns 1


# Example
import math

x = math.pi
print(x) # Output: 3.141592653589793