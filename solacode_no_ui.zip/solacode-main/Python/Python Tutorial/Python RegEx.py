# Python RegEx (Regular Expressions)
# RegEx Module
import re


# RegEx in Python
import re

txt = "The rain in Spain"
x = re.search("^The.*Spain$", txt) # Check if the string starts with "The" and ends with "Spain"


# RegEx Functions
# Function	Description
# findall	Returns a list containing all matches
# search	Returns a Match object if there is a match anywhere in the string
# split	    Returns a list where the string has been split at each match
# sub	    Replaces one or many matches with a string


# Metacharacters
# Metacharacters are characters with a special meaning:
# Character	Description	                                            Example
# []	    A set of characters	                                    "[a-m]"	
# \	        Signals a special seq (also use to esc special char)	"\d"	
# .	        Any character (except newline character)	            "he..o"	
# ^	        Starts with	                                            "^hello"	
# $	        Ends with	                                            "planet$"	
# *	        Zero or more occurrences	                            "he.*o"	
# +	        One or more occurrences	                                "he.+o"	
# ?	        Zero or one occurrences	                                "he.?o"	
# {}	    Exactly the specified number of occurrences	            "he.{2}o"	
# |	        Either or	                                            "falls|stays"	
# ()	    Capture and group	 


# Flags
# You can add flags to the pattern when using regular expressions.
# Flag	        Shorthand	Description	Try it
# re.ASCII	    re.A	    Returns only ASCII matches	
# re.DEBUG		              Returns debug information	
# re.DOTALL	    re.S	    Makes the . character match all characters (including newline character)	
# re.IGNORECASE	re.I	    Case-insensitive matching	
# re.MULTILINE	re.M	    Returns only matches at the beginning of each line	
# re.NOFLAG		            Specifies that no flag is set for this pattern	
# re.UNICODE	re.U	    Returns Unicode matches.
# re.VERBOSE	re.X	    Allows whitespaces and comments inside patterns. Makes the pattern more readable

# Example
txt = "Åland"
#Find all ASCII matches:
print(re.findall("\w", txt, re.ASCII)) # Output: ['l', 'a', 'n', 'd']


# Special Sequences
# Character	Description	                                                        Example
# \A	Rtrns if the specified characters are at the beginning of the string	"\AThe"	
# \b	Rtrns whr the specified characters are at the beginning or at the end of a word
#           (the "r" in the beginning is making sure that the string is being treated as a "raw string")	r"\bain"
# \B	Rtrns whr the specified characters are present, but NOT at the beginning (or at the end) of a word
#           (the "r" in the beginning is making sure that the string is being treated as a "raw string")	r"\Bain"
# \d	Rtrns whr the string contains digits (numbers from 0-9)	                "\d"	
# \D	Rtrns whr the string DOES NOT contain digits	                        "\D"	
# \s	Rtrns whr the string contains a white space character	                "\s"	
# \S	Rtrns whr the string DOES NOT contain a white space character	        "\S"	
# \w	Rtrns whr the string contains any word characters (characters from a to Z, digits from 0-9, and the underscore _ character)	"\w"	
# \W	Rtrns whr the string DOES NOT contain any word characters	            "\W"	
# \Z	Rtrns if the specified characters are at the end of the string	        "Spain\Z


# Example
txt = "The rain in Spain"
x = re.findall(r"\Bain", txt)
print(x) # Output: ['ain', 'ain']


# Sets
# Set	        Description
# [arn]	        Returns a match where one of the specified characters (a, r, or n) is present	
# [a-n]	        Returns a match for any lower case character, alphabetically between a and n	
# [^arn]	    Returns a match for any character EXCEPT a, r, and n	
# [0123]	    Returns a match where any of the specified digits (0, 1, 2, or 3) are present	
# [0-9]	        Returns a match for any digit between 0 and 9	
# [0-5][0-9]	Returns a match for any two-digit numbers from 00 and 59	
# [a-zA-Z]	    Returns a match for any character alphabetically between a and z, lower case OR upper case	
# [+]	        In sets, +, *, ., |, (), $,{} has no special meaning, so [+] means: return a match for any + character in the string.


# Example
txt = "The rain in Spain"
#Check if the string has any characters between a and n:
x = re.findall("[a-n]", txt)
print(x) # Output: ['a', 'i', 'n', 'i', 'n', 'a', 'i']


# The findall() Function
txt = "The rain in Spain"
x = re.findall("ai", txt)
print(x) # Output: ['ai', 'ai']


# The search() Function
txt = "The rain in Spain"
x = re.search("\s", txt)
print("The first white-space character is located in position:", x.start()) # Output: The first white-space character is located in position: 3


# The split() Function
txt = "The rain in Spain"
x = re.split("\s", txt)
print(x) # Output: ['The', 'rain', 'in', 'Spain']


# Split the string only at the first occurrence
txt = "The rain in Spain"
x = re.split("\s", txt, 1)
print(x) # Output: ['The', 'rain in Spain']


# The sub() Function
txt = "The rain in Spain"
x = re.sub("\s", "9", txt)
print(x) # Output: The9rain9in9Spain


# Replace the first 2 occurrences:
txt = "The rain in Spain"
x = re.sub("\s", "9", txt, 2)
print(x) # Output: The9rain9in Spain


# Match Object
txt = "The rain in Spain"
x = re.search("ai", txt)
print(x) # Output: <re.Match object; span=(5, 7), match='ai'>


# Print the position (start- and end-position) of the first match occurrence.
txt = "The rain in Spain"
x = re.search(r"\bS\w+", txt) # Match words that start with 'S'
print(x.span()) # Output: (12, 17)


# Print the string passed into the function:
txt = "The rain in Spain"
x = re.search(r"\bS\w+", txt)
print(x.string) # Output: The rain in Spain


# Print the part of the string where there was a match.
txt = "The rain in Spain"
x = re.search(r"\bS\w+", txt)
print(x.group()) # Output: Spain


