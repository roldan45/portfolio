# Loop Dictionaries
# Loop through a dictionary
thisdict = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
for x in thisdict:
  print(x)
# Output: brand
# Output: model
# Output: year


# Print all values in the dictionary
for x in thisdict:
  print(thisdict[x])
# Output: Ford
# Output: Mustang
# Output: 1964


# values() method
for x in thisdict.values():
  print(x)


# keys() method
for x in thisdict.keys():
  print(x)


# Loop through both keys and values
for x, y in thisdict.items():
  print(x, y)
# Output: brand Ford
# Output: model Mustang
# Output: year 1964