# Unpack Tuples
# Unpacking a Tuple
fruits = ("apple", "banana", "cherry")
(green, yellow, red) = fruits
print(green) # Output: apple
print(yellow)   # Output: banana
print(red) # Output: cherry


# Using Asterisk*
fruits = ("apple", "banana", "cherry", "strawberry", "raspberry")
(green, *yellow, red) = fruits
print(green) # Output: apple
print(yellow) # Output: ['banana', 'cherry', 'strawberry']
print(red) # Output: raspberry