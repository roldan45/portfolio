# Python Virtual Environment
# A virtual environment in Python is an isolated environment on your computer
# where you can run and test your Python projects.


# Creating a Virtual Environment
# Windows
# C:\Users\Your Name> python -m venv myfirstproject


# The file/folder structure will look like this:
# myfirstproject
#   Include
#   Lib
#   Scripts
#   .gitignore
#   pyvenv.cfg


# Activate Virtual Environment
# C:\Users\Your Name> myfirstproject\Scripts\activate


# Result
# (myfirstproject) C:\Users\Your Name>


# Install Packages
# (myfirstproject) C:\Users\Your Name> pip install cowsay


# Result
# Collecting cowsay
#   Downloading cowsay-6.1-py3-none-any.whl.metadata (5.6 kB)
# Downloading cowsay-6.1-py3-none-any.whl (25 kB)
# Installing collected packages: cowsay
# Successfully installed cowsay-6.1
# [notice] A new release of pip is available: 25.0.1 -> 25.1.1
# [notice] To update, run: python.exe -m pip install --upgrade pip


# Using Package
# test.py
import cowsay
cowsay.cow("Good Mooooorning!")


# Execute the file
# (myfirstproject) C:\Users\Your Name> python test.py
#   _________________
# | Good Mooooorning! |
#   =================
#                  \
#                   \
#                     ^__^
#                     (oo)\_______
#                     (__)\       )\/\
#                         ||----w |
#                         ||     ||


# Deactivate Virtual Environment
# (myfirstproject) C:\Users\Your Name> deactivate
# C:\Users\Your Name>


# Delete Virtual Environment
# C:\Users\Your Name> rmdir /s /q myfirstproject
