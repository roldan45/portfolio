# Slicing
b = "Hello, World!"
print(b[2:5])  # Output: llo


# Slice From the Start
b = "Hello, World!"
print(b[:5])  # Output: Hello


# Slice To the End
b = "Hello, World!"
print(b[2:])  # Output: llo, World!


# Negative Indexing
b = "Hello, World!"
print(b[-5:-2])  # Output: orl