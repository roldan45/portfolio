# Loop Sets
# Loop Items
thisset = {"apple", "banana", "cherry"}
for x in thisset:
  print(x)
# Output: apple
# Output: banana
# Output: cherry