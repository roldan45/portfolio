# Access Set Items
# Access Items
thisset = {"apple", "banana", "cherry"}
for x in thisset:
  print(x)


# Check if "banana" is present in the set:
thisset = {"apple", "banana", "cherry"}
print("banana" in thisset)


# Check if "banana" is NOT present in the set:
thisset = {"apple", "banana", "cherry"}
print("banana" not in thisset)