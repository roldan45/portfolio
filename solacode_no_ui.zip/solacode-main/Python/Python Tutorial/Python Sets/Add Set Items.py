# Add Set Items
# Add Items
thisset = {"apple", "banana", "cherry"}
thisset.add("orange")
print(thisset)  # Output: {'banana', 'cherry', 'orange', 'apple'}


# Add Sets
thisset = {"apple", "banana", "cherry"}
tropical = {"pineapple", "mango", "papaya"}
thisset.update(tropical)
print(thisset)  # Output: {'banana', 'cherry', 'apple', 'mango', 'pineapple', 'papaya'}


# Add Any Iterable
thisset = {"apple", "banana", "cherry"}
mylist = ["kiwi", "orange"]
thisset.update(mylist)
print(thisset)  # Output: {'banana', 'cherry', 'orange', 'apple', 'kiwi'}