# Add List Items
# Append Items
thislist = ["apple", "banana", "cherry"]
thislist.append("orange")
print(thislist) # Output: ['apple', 'banana', 'cherry', 'orange']


# Insert Items
thislist = ["apple", "banana", "cherry"]
thislist.insert(1, "orange")
print(thislist) # Output: ['apple', 'orange', 'banana', 'cherry']


# Extend List
thislist = ["apple", "banana", "cherry"]
tropical = ["mango", "pineapple", "papaya"]
thislist.extend(tropical)
print(thislist) # Output: ['apple', 'banana', 'cherry', 'mango', 'pineapple', 'papaya']


# Add Any Iterable
thislist = ["apple", "banana", "cherry"]
thistuple = ("kiwi", "orange")
thislist.extend(thistuple)
print(thislist) # Output: ['apple', 'banana', 'cherry', 'kiwi', 'orange']