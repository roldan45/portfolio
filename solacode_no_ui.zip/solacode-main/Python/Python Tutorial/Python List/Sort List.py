# Sort Lists
# Sort List Alphanumerically
thislist = ["orange", "mango", "kiwi", "pineapple", "banana"]
numlist = [100, 50, 65, 82, 23]
thislist.sort()
numlist.sort()
print(thislist) # Output: ['banana', 'kiwi', 'mango', 'orange', 'pineapple']
print(numlist) # Output: [23, 50, 65, 82, 100]


# Sort Descending
thislist = ["orange", "mango", "kiwi", "pineapple", "banana"]
thislist.sort(reverse = True)
print(thislist) # Output: ['pineapple', 'orange', 'mango', 'kiwi', 'banana']


# Customize Sort Function
def myfunc(n):
  return abs(n - 50)
thislist = [100, 50, 65, 82, 23]
thislist.sort(key = myfunc)
print(thislist) # Output: [50, 65, 82, 23, 100]


# Case Insensitive Sort
thislist = ["banana", "Orange", "Kiwi", "cherry"]
thislist.sort()
print(thislist) # Output: ['banana', 'cherry', 'Kiwi', 'Orange']


# Reverse Order
thislist = ["banana", "Orange", "Kiwi", "cherry"]
thislist.reverse()
print(thislist) # Output: ['cherry', 'Kiwi', 'Orange', 'banana']

